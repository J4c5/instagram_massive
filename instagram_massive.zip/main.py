# Path
from playwright.sync_api import sync_playwright
import random, re, requests, json

# Src
from src.log import log
from src.debug import DebugAwait
from src.getnames import Names ; n = Names()

# Account Class
class Account:
    def __init__(self):
        self.Username = ""
        self.Email = ""
        self.Name = ""
        self.Password = ""
        self.year = ""

# Get New Email
def GetEmail(page, ac):
    log("obtendo email..")

    page.goto("https://cryptogmail.com/")
    page.wait_for_selector(".field--value")
    email =  page.evaluate("""()=>{
        const email = document.getElementsByClassName("field--value js-email")
        const e = email[0]
        return e.innerText
    }""")
    log(f"Email: {email}")
    ac.Email = email

# Get New Code
def GetCode(email):
    log("obtendo codigo (pode demorar)")
    while True:
        res = requests.get(f"https://cryptogmail.com/api/emails?inbox={email}").text
        if re.search("<!DOCTYPE html>", res):
            pass
        else:
            js = json.loads(res)
            code = js["data"][0]["subject"]
            code = code.replace(" is your Instagram code", "")
            return code

# Instagram
def instagram():
    with sync_playwright() as p:
        ac = Account()

        login_url = "https://www.instagram.com/sem/campaign/emailsignup/"

        log("abrindo browser")
        browser = p.chromium.launch(headless=False)

        log("abrindo pagina")
        page = browser.new_page()

        GetEmail(page, ac)

        log(f"indo ate: {login_url}")
        page.goto(login_url)
        page.goto("https://www.instagram.com/accounts/emailsignup/")

        selctor_email    = "div.WZdjL:nth-child(4) > div:nth-child(1) > label:nth-child(1) > input:nth-child(2)"
        selctor_name     = "div.WZdjL:nth-child(5) > div:nth-child(1) > label:nth-child(1) > input:nth-child(2)"
        selctor_username = "div.WZdjL:nth-child(6) > div:nth-child(1) > label:nth-child(1) > input:nth-child(2)"
        selctor_password = "div.WZdjL:nth-child(7) > div:nth-child(1) > label:nth-child(1) > input:nth-child(2)"
        selctor_btn_sub  = "div.bkEs3:nth-child(1) > button:nth-child(1)"
        
        log("esperando pela pagina")
        page.wait_for_selector(selctor_email)

        # auto
        def Set_Email():
            page.type(selctor_email, ac.Email)
        
        def Set_Name():
            name = n.get_new_name()    
            log(f"name is: {name}")
            page.type(selctor_name, name)
            ac.Name = name

        def Set_Password_and_Name(name):
            pwd = str(random.randint(0, 72) * 2)
            pwd += name+pwd
            pwd = pwd.replace(" "  , f"_{random.randint(0, 6)}_")

            user = pwd.replace("_", "__")
            log(f"Pas's: {pwd}, Username's: {user}")
            page.type(selctor_password, pwd)
            page.type(selctor_username, user)

            ac.Password = pwd
            ac.Username = user

        def SelectDate():
            log("selecionando idade")
            page.wait_for_selector("#react-root > section > main > div > div > div:nth-child(1) > div > div.qF0y9.Igw0E.IwRSH.eGOV_._4EzTm.lC6p0.g6RW6")
            page.evaluate("""()=>{
                const Opt = document.getElementsByClassName("h144Z  ")
                Opt[2].options.selectedIndex = 23
            }""")
            page.click("#react-root > section > main > div > div > div:nth-child(1) > div > div.qF0y9.Igw0E.IwRSH.eGOV_._4EzTm.bkEs3.DhRcB > div > div > span > span:nth-child(3) > select")
            page.click("""//*[@id="react-root"]/section/main/div/div/div[1]/div[1]/span""")
            page.click("#react-root > section > main > div > div > div:nth-child(1) > div > div.qF0y9.Igw0E.IwRSH.eGOV_._4EzTm.lC6p0.g6RW6 > button")

        def SelectCode(code):
            log(f"codigo: {code}")
            page.type("#react-root > section > main > div > div > div:nth-child(1) > div.qF0y9.Igw0E.IwRSH.eGOV_._4EzTm > form > div > div:nth-child(1) > input", code)
            page.click("#react-root > section > main > div > div > div:nth-child(1) > div.qF0y9.Igw0E.IwRSH.eGOV_._4EzTm > form > div > div:nth-child(2) > button")
        
        def SaveAcc(ac):
            log("conta salva em: ./accs.txt")
            file = open("accs.txt", "a")
            payload = f"""Email: {ac.Email}\nSenha: {ac.Password}\nUsername: {ac.Username}\n"""
            file.write(payload)
            file.close()

        Set_Email()
        Set_Name()
        Set_Password_and_Name(ac.Name)
        page.click(selctor_btn_sub)
        
        SelectDate()
        code = GetCode(ac.Email)
        SelectCode(code)
        SaveAcc(ac)
        # *
        DebugAwait()

# Main Func
if __name__ == "__main__":
    instagram()        