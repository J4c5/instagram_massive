import random

names = ["marillia", "marine", "ana", "vitoria", "vivi", "surtada", "marcia", "juju", "karol", "karoline", "coralline", "sophia", "emily", "sofia", "sara", "alice", "jessica", "irelia", "issabella", "leticia", "isadora", "laura", "manu", "manuela", "luisa", "maria", "joselli"]
subnames  = ["silva", "alckerman", "mendonça", "carlo", "uzumaki", "oliveira", "santos", "souza", "ferreira", "alves", "lima", "gomes", "ribeiro", "martins", "carvalho", "aumeida", "lopes", "soares", "fernandes", "vieira", "barbosa", "rocha", "dias", "naicimento", "nunes", "machado", "cardoso", "teixeira"]


def get_new_name():
    def F(list):
        return random.randint(0, len(list)) - 1

    return f"{names[F(names)]} {subnames[F(subnames)]}"


class Names:
    def __init__(self):
        self.get_new_name = get_new_name