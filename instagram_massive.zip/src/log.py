def log(text):
    print(f"log - {text}")