from time import sleep as t

def DebugAwait():
    import sys
    import time
    print("--")
    print("debug - Esperando Por Ctrl+C")
    
    def spinning_cursor():
        while True:
            for cursor in '|/-\\':
                yield cursor
    try:
        spinner = spinning_cursor()
        while True:
            sys.stdout.write(next(spinner))
            sys.stdout.flush()
            time.sleep(0.1)
            sys.stdout.write('\b')
    except KeyboardInterrupt: 
        exit(0)